const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const cors = require("cors");
const fs = require("fs");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

app.use(cors());
app.use(express.json());

// File DB
const DB_FILE = path.join(__dirname, "data.json");

// Baca DB
function readDB() {
  if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(DB_FILE, JSON.stringify({ users: {} }, null, 2));
  }
  return JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
}

// Tulis DB
function writeDB(data) {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}

let onlineUsers = {};

io.on("connection", (socket) => {
  console.log(`[CONNECT] ${socket.id}`);

  // User join
  socket.on("join", (userId) => {
    const db = readDB();
    if (!db.users[userId]) {
      db.users[userId] = { balance: 50000 };
      writeDB(db);
      console.log(`[NEW USER] ${userId} | saldo: 50000`);
    } else {
      console.log(`[JOIN] ${userId} | saldo: ${db.users[userId].balance}`);
    }

    socket.join(userId);
    onlineUsers[userId] = socket.id;

    // Kirim saldo awal
    socket.emit("saldoUpdate", { userId, balance: db.users[userId].balance });
  });

  // Admin update saldo
  socket.on("adminUpdateSaldo", ({ userId, balance }) => {
    const db = readDB();
    if (!db.users[userId]) db.users[userId] = { balance: 0 };
    db.users[userId].balance = Number(balance);
    writeDB(db);

    io.to(userId).emit("saldoUpdate", { userId, balance: Number(balance) });
    console.log(`[UPDATE] ${userId} = ${balance}`);
  });

  // Admin reset saldo
  socket.on("adminResetSaldo", (userId) => {
    const db = readDB();
    db.users[userId] = { balance: 0 };
    writeDB(db);

    io.to(userId).emit("saldoUpdate", { userId, balance: 0 });
    console.log(`[RESET] ${userId}`);
  });

  // Admin check saldo
  socket.on("adminCheckSaldo", (userId) => {
    const db = readDB();
    const balance = db.users[userId]?.balance || 0;
    socket.emit("saldoUpdate", { userId, balance });
  });

  socket.on("disconnect", () => {
    const uid = Object.keys(onlineUsers).find((u) => onlineUsers[u] === socket.id);
    if (uid) delete onlineUsers[uid];
    console.log(`[DISCONNECT] ${socket.id} | Online: ${Object.keys(onlineUsers).length}`);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, "0.0.0.0", () => console.log(`Server running on port ${PORT}`));
